package com.example.purchaseapp;

public class Item {

    private String name;
    private String purchaseDate;
    private String expirationDate;
    private double price;

    public Item(String name, String purchaseDate, String expirationDate, double price) {
        this.name = name;
        this.purchaseDate = purchaseDate;
        this.expirationDate = expirationDate;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public double getPrice() {
        return price;
    }
}
