package com.example.cp3407project;
package com.example.purchaseapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Item> itemList;
    private ItemAdapter itemAdapter;
    private TextView totalPriceTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemList = new ArrayList<>();
        itemAdapter = new ItemAdapter(this, itemList);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(itemAdapter);

        totalPriceTextView = findViewById(R.id.totalPriceTextView);
        updateTotalPrice();

        EditText itemNameEditText = findViewById(R.id.itemNameEditText);
        EditText itemPriceEditText = findViewById(R.id.itemPriceEditText);
        EditText itemExpirationEditText = findViewById(R.id.itemExpirationEditText);
        Button addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = itemNameEditText.getText().toString();
                String priceString = itemPriceEditText.getText().toString();
                String expiration = itemExpirationEditText.getText().toString();

                if (!name.isEmpty() && !priceString.isEmpty() && !expiration.isEmpty()) {
                    double price = Double.parseDouble(priceString);

                    // 获取当前日期
                    String purchaseDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    Item newItem = new Item(name, purchaseDate, expiration, price);
                    itemList.add(newItem);
                    itemAdapter.notifyDataSetChanged();
                    updateTotalPrice();

                    itemNameEditText.setText("");
                    itemPriceEditText.setText("");
                    itemExpirationEditText.setText("");
                }
            }
        });
    }

    private void updateTotalPrice() {
        double totalPrice = 0.0;
        for (Item item : itemList) {
            totalPrice += item.getPrice();
        }
        totalPriceTextView.setText("Total Price: $" + totalPrice);
    }
}